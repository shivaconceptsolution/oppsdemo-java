package package2;
import package1.*;
public class AccessExample3 {

	public static void main(String[] args) {
		AcceessSpecifierExample obj = new AcceessSpecifierExample();
		
		obj.fun4();
		

	}

}
