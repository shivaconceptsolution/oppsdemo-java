package package2;

import package1.AcceessSpecifierExample;

public class AccessExample4 extends AcceessSpecifierExample {

	public static void main(String[] args) {
		AccessExample4 obj = new AccessExample4();
		obj.fun2();
		obj.fun4();

	}

}
