package overriding;

public class BillingSystem {
	 void softwareinfo()
	{
		System.out.println("Welcome in billing");
	}
   void billing()
    {
    	System.out.println("Billing System OLD");
    }
}
