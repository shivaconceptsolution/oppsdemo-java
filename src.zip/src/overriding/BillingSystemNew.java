package overriding;

public class BillingSystemNew extends BillingSystem {
	void billing()
    {
    	System.out.println("Billing System New");
    }
	
	
	public static void main(String args[])
	{
		BillingSystem obj = new BillingSystemNew();
		obj.billing();
		obj.softwareinfo();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
