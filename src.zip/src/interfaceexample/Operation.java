package interfaceexample;

public interface Operation {
   void addition();
   void substraction();
}
