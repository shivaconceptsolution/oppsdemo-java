package interfaceexample;

public class AreaImpl implements Area,Operation {
    float area;
    float r=2;
    float b=200;
    float h=2;
	@Override
	public void circle() {
		
		area = 3.14F*r*r;
		System.out.println(area);
	}

	@Override
	public void triangle() {
		area = (b*h)/2;
		System.out.println(area);
	}
	
	public static void main(String args[])
	{
		Area obj = new AreaImpl(); //loose coupling 
		obj.circle();
		obj.triangle();
		obj.fun1();
		Area.fun();
		Operation obj1 = new AreaImpl();
		obj1.addition();
		obj1.substraction();
		
	}

	@Override
	public void addition() {
		System.out.println("Addition is "+(b+h));
		
	}

	@Override
	public void substraction() {
		System.out.println("Substraction is "+(b-h));
		
	}

}
