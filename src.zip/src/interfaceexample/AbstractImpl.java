package interfaceexample;

public class AbstractImpl extends AbstractDemo {

	public static void main(String[] args) {
		AbstractDemo obj = new AbstractImpl();
		obj.fun();
		obj.fun(100,200);

	}

	@Override
	void fun() {
		 System.out.println("abstract method");
	}

}
