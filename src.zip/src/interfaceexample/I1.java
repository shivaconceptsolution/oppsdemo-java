package interfaceexample;

public interface I1 {
void fun();
}
