package interfaceexample;

public interface I2 extends I1{
	void fun1();
}
