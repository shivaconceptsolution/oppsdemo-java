package interfaceexample;

public abstract class AbstractDemo {
  void fun(int a,int b)
  {
	  System.out.println("normal method"+(a+b));
  }
  abstract void fun();
}
