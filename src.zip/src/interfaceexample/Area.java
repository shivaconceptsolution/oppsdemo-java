package interfaceexample;

public interface Area {
	static void fun()
	{
		System.out.println("Static Method of Interface");
	}
	default void fun1()
	{
		System.out.println("Default Method of Interface");
	}
   void circle();
   void triangle();
}
