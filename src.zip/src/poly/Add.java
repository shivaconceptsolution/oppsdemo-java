package poly;

public class Add {
	
	void add(Integer x, int y)
	{
		System.out.println(x+y+2);
	}
	void add(int x, int y)
	{
		System.out.println(x+y);
	}
	void add(int x, float b)
	{
		
	}
	void add(float x, float b)
	{
		System.out.println(x+b);
	}
	void add(float x, int b)
	{
		
	}
	
	public static void main(String args[])
	{
		Add obj= new Add();
		obj.add(new Integer(10), 2);
		obj.add(3.14F, 4.24F);
	}

}
