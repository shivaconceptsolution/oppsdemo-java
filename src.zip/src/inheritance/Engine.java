package inheritance;

public class Engine {
   void engineInfo()
   {
	   System.out.println("Best Mileage Engine");
   }
}
