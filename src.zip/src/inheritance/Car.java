package inheritance;

public class Car {
   String color;
   int price;
   void acceptCarInfo(String color,int price)
   {
	   this.color=color;
	   this.price=price;
   }
   void displayCarInfo()
   {
	   System.out.println("Color is "+color + "Price is "+price);
   }
   
}
