package inheritance;

public class Maruti extends Car {
   void marutiInfo()
   {
	  /// super.acceptCarInfo("Green",450000);
	  // super.displayCarInfo();
	   Engine o = new Engine();
	   o.engineInfo();
   }
   
  
}
