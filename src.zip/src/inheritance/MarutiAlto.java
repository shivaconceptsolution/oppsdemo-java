package inheritance;

public class MarutiAlto extends Maruti {
   void marutiAltoInfo()
   {
	  // super.marutiInfo();
	   System.out.println("Very comfortable for city ride");
   }
   
}
