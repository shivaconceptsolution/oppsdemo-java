package inheritance;

public class User {
	 public static void main(String args[])
	   {
		 try
		 {
		   MarutiAlto obj =null;
		   obj.acceptCarInfo("White",650000);
		   obj.displayCarInfo();
		   obj.marutiInfo();
		   obj.marutiAltoInfo();
		 }
		 catch(NullPointerException ex)
		 {
			 System.out.println("Error");
		 }
	   }
}
