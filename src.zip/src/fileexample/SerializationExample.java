package fileexample;
import java.io.*;
public class SerializationExample  {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		File f = new File("d://stuser.txt");
		Student obj = new Student(1001,"xyz");
		FileOutputStream fo = new FileOutputStream(f);
		ObjectOutputStream oo = new ObjectOutputStream(fo);
		oo.writeObject(obj);
		oo.close();
		
		Student obj1 = null;
		FileInputStream fi = new FileInputStream(f);
		ObjectInputStream oi = new ObjectInputStream(fi);
		obj1=(Student)oi.readObject();
		System.out.println(obj1.rno + " " + obj1.sname);
		oi.close();
	}

}
