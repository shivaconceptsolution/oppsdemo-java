package fileexample;
import java.util.Scanner;
import java.io.*;
public class FilehandlingExample {

	public static void main(String[] args) throws IOException {
	
		while(true)
		{
		File fi = new File("d://biodata.txt");
		if(!fi.exists())
		{
			fi.createNewFile();
		}
		FileWriter fw = new FileWriter(fi,true);
		BufferedWriter bw = new BufferedWriter(fw);
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
	    String name = sc.next();
		bw.write(name);
		bw.newLine();
		System.out.println("Enter contact no");
		String cnct = sc.next();
		bw.write(cnct);
		bw.newLine();
		bw.close();
		fw.close();
        System.out.println("Press c for continue, e for exit");
        if(sc.next().charAt(0)=='e')
        {
        	break;
        }
        
        
		} 
	}

}
