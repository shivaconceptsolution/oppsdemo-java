package fileexample;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileDemo1 {

	public static void main(String[] args) throws IOException {
		File f = new File("D://ram.txt");
		FileWriter fw = new FileWriter(f);
		fw.write("Welcome in SCS");
		fw.close();
		
	}

}
