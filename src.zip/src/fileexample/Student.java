package fileexample;

import java.io.Serializable;

public class Student implements Serializable {
 transient int rno;
String sname;
Student(int rno,String sname)
{
	this.rno=rno;
	this.sname=sname;
}
}
