package fileexample;
import java.io.*;
import java.util.Scanner;

public class ReadFileData {
   void readFile() throws IOException
   {
		File f = new File("d://biodata.txt");
		FileInputStream fi = new FileInputStream(f);
		byte arr[] = new byte[50];
	    int s =0;
	  
	    while((s = fi.read(arr))!=-1)
	    {
	    	String s1 = new String(arr); // byte array to String
	    	System.out.println(s1);
	    	
	    }
	   
		fi.close();
   }
   void writeFile() throws IOException
   {
	   
		File fi = new File("d://biodata.txt");
		if(!fi.exists())
		{
			fi.createNewFile();
		}
		FileOutputStream fw = new FileOutputStream(fi,true);
		String data = "abcd";
		byte arr[] = data.getBytes();
		fw.write(arr);
		fw.close();
		
		
   }
	public static void main(String[] args) throws IOException {
	
		ReadFileData  obj = new ReadFileData();
		obj.writeFile();
		obj.readFile();

	}

}
