package collectionexample;

import java.util.LinkedList;

public class LinkedlistExample {

	public static void main(String[] args) {
		LinkedList<String> lt = new LinkedList<String>();
		lt.add("C");
		lt.add("Java");
		lt.addFirst(".NET");
		lt.addLast("PHP");
		lt.add("PYTHON");
		lt.removeFirst();
		lt.removeLast();
	//	System.out.println(lt.get(2) + ""+ lt.get(1) + ""+ lt.get(0));
	/*	for(Object o:lt)
		{
			System.out.println(o);
		}*/

	}

}
