package collectionexample;

import java.util.Iterator;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		Vector<Integer> obj = new Vector<Integer>();
		obj.add(101);
		obj.add(103);
		obj.add(104);
		obj.add(107);
		Iterator it = obj.iterator();
		while(it.hasNext())
		{
			Object o = it.next();
			System.out.println(o);
		}

	}

}
