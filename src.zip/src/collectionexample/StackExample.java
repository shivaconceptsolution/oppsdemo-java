package collectionexample;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		Stack s = new Stack();
		s.push("C");
		s.push("CPP");
		s.push("DS");
		s.push("JAVA");
		System.out.println(s.peek());
		while(s.size()!=0)
		{
			System.out.println(s.pop());
		}
	

	}

}
