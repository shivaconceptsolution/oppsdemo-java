package collectionexample;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class HashSetExample {

	public static void main(String[] args) {
	///	HashSet<String> hs = new HashSet<String>();
	///	LinkedHashSet<String> hs = new LinkedHashSet<String>();
		//TreeSet<String> hs = new TreeSet<String>();
	//	Set<String> hs = new TreeSet<String>();
		SortedSet<String> hs = new TreeSet<String>();
		hs.add("1");
		hs.add("9");
		hs.add("7");
		hs.add("2");
		hs.add("3");
		//hs.remove("Android");
		for(Object o:hs)
		{
			System.out.println(o);
		}
		

	}

}
