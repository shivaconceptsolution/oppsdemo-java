package collectionexample;

import java.util.ArrayDeque;
import java.util.ArrayList;

public class ArrayDqueueExample {

	public static void main(String[] args) {
		ArrayDeque<String> obj = new ArrayDeque<String>();
		obj.addFirst("C");
		obj.addFirst("CPP");
		obj.addFirst("DS");
		obj.removeLast();
		for(Object o:obj)
		{
			System.out.println(o);
		}
		
		

	}

}
