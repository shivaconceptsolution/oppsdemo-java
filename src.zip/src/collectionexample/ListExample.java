package collectionexample;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ListExample {

	public static void main(String[] args) {
	//	ArrayList obj = new ArrayList();
	//	List obj = new ArrayList();
	//	Collection obj = new ArrayList();
		ArrayList<String> obj = new ArrayList<String>();
		obj.add("C");
		//obj.add(2500);
		obj.add("Java");
		obj.add("25k");
		//obj.remove("C");
		for(Object o:obj)
		{
			System.out.println(o);
		}
		for(int i=0;i<obj.size();i++)
		{
			System.out.println(obj.get(i));
		}
		System.out.println("List Item are");
		Iterator it = obj.iterator();
		while(it.hasNext())
		{
			Object o = it.next();
			System.out.println(o);
		}
		
		System.out.println("Items are in forward");
		ListIterator lt = obj.listIterator();
		while(lt.hasNext())
		{
			Object o = lt.next();
			System.out.println(o);
		}
		System.out.println("Items are in backward");
		
		while(lt.hasPrevious())
		{
			Object o = lt.previous();
			System.out.println(o);
		}
		

	}

}
