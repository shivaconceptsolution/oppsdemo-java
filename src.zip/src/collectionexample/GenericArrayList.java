package collectionexample;

import java.util.ArrayList;
import java.util.Collections;

public class GenericArrayList {

	public static void main(String[] args) {
		ArrayList<Emp> obj = new ArrayList<Emp>();
		obj.add(new Emp(1002,"XYZ",11000));
		obj.add(new Emp(1007,"MNO",50000));
		obj.add(new Emp(1001,"ABC",42000));
		Collections.sort(obj, new IDComparator());
		for(Emp e:obj)
		{
			System.out.println(e);
		}
		Collections.sort(obj, new SalaryComparator());
		for(Emp e:obj)
		{
			System.out.println(e);
		}

	}

}
