package collectionexample;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MapExample {

	public static void main(String[] args) {
	//	HashMap<String,String> obj = new HashMap<String,String>();
	 // LinkedHashMap<String,String>	obj = new LinkedHashMap<String,String>();
	 // TreeMap<String,String>	obj = new TreeMap<String,String>();
		Map<String,Integer> obj = new Hashtable<String,Integer>();
		int a=1001;
		obj.put("rno", a);
		obj.put("sname", 10);
		obj.put("branch", 30);
		obj.put("fees", 500);
		Set<Map.Entry<String,Integer>> se = obj.entrySet();
		for(Map.Entry<String,Integer> me:se)
		{
			System.out.println(me.getKey() + "," + me.getValue());
		}
		

	}

}
