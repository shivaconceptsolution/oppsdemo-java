package collectionexample;

import java.util.ArrayList;
import java.util.Collections;

public class MaxArrList {

	public static void main(String[] args) {
		ArrayList<Integer> obj = new ArrayList<Integer>();
		obj.add(104);
		obj.add(102);
		obj.add(10);
		obj.add(97);
		obj.add(12);
		 for(Object o:obj)
		 {
			 obj.remove(o);
		 }
		Object arr[] = obj.toArray();
		
	//	Collections.sort(obj);
	//	System.out.println(Collections.max(obj));
	//	System.out.println(Collections.min(obj));
		for(int i=0;i<arr.length;i++)
	    {
			for(int j=i+1;j<arr.length;j++)
			{
				if(Integer.parseInt(arr[i].toString()) > Integer.parseInt(arr[j].toString()))
				{
				Object temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				}
			}
			System.out.println(arr[i]);
	    	
	    }

	}

}
