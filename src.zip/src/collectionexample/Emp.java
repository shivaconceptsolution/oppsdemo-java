package collectionexample;

public class Emp {

	int empid;
	private String empname;
	int sal;
	Emp(int empid, String empname, int sal)
	{
		this.empid=empid;
		this.empname=empname;
		this.sal=sal;
	}

	public String toString()
	{
		return "Empid is "+empid + " name is "+empname + "salary is "+sal;
	}

	
}
