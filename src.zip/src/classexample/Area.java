package classexample;

public interface Area {
 void area();
}
