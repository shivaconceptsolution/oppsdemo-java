package classexample;

public class Electronics {
  static class Mobile
   {
	   public static void displayMobile()
	   {
		   System.out.println("mobile info");
	   }
	  
   }
   class Laptop
   {
	   public void displayLaptops()
	   {
		   System.out.println("laptop info");
	   }
   }
}
