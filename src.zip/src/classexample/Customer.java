package classexample;

public class Customer {

	public static void main(String[] args) {
		
		 Electronics.Mobile.displayMobile();
		
		Electronics obj1 = new Electronics();
		obj1.new Laptop().displayLaptops();;
		

	}

}
