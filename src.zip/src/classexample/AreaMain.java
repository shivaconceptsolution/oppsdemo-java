package classexample;

public class AreaMain {

	public static void main(String[] args) {
		Area obj = new Area(){

			@Override
			public void area() {
				System.out.println("Anonymous class");
				
			}
			
		};
		
		obj.area();  //calling of anonymous class method

	}

}
