package scs.oopsexample;
import java.util.*;
public class Student {
	private int rno;
	private String sname;
	private String schoolname;
	Scanner sc = new Scanner(System.in);
	void accept()
	{
		schoolname="SCS";
		System.out.println("Enter rno");
		rno=sc.nextInt();
		System.out.println("Enter name");
		sname=sc.next();
	}
	void display()
	{
		System.out.println("schoolname is "+schoolname);
		System.out.println("Rno is "+rno);
		System.out.println("Name is "+sname);
	}

	
}
