package scs.oopsexample;

public class MemberFunctionExample {
    int a=100,b=20,c;
	void addition() //default no return type
	{
		c=a+b;
		System.out.println(c);
	}
	int substraction()  //default, return type
	{
		return a-b;
	}
	
	void division(int x, int y)
	{
		c=x/y;
		System.out.println(c);
	}
	int muliplication(int x, int y)
	{
		return x*y;
	}
	public static void main(String[] args) {
		MemberFunctionExample obj = new MemberFunctionExample();
		obj.addition();
		int res = obj.substraction();
		System.out.println(res);
		obj.division(100, 2);
		int res1=obj.muliplication(10, 2);
		System.out.println(res1);
									
	}

}
