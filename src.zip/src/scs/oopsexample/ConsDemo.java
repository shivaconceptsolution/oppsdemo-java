package scs.oopsexample;

public class ConsDemo {
	int a,b,c;
	ConsDemo()
	{
		a=100;
		 b=200;
	}
	ConsDemo(int a, int b)
	{
	   this.a=a;  // this is a keyword that contain address of current object
	   this.b=b;
	}
	
	ConsDemo(ConsDemo cd)
	{
		this.a=cd.a;
		this.b=cd.b;
	}
	void additionLogic()
	{
		c = a+b;
	}
	void display()
	{
		System.out.println(c);
		
	}
	
	public static void main(String args[])
	{
		ConsDemo obj = new ConsDemo();
		obj.additionLogic();
		obj.display();
		ConsDemo obj1 = new ConsDemo(100,20);
		obj1.additionLogic();
		obj1.display();
		ConsDemo obj2 = new ConsDemo(obj1);
		obj2.additionLogic();
		obj2.display();
	}

}
