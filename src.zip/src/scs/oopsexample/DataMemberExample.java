package scs.oopsexample;

public class DataMemberExample {

    int x=5;  //global dynamic data member, non static, instance;
    
    void fun()
    {
    	int x=10;  //local dynamic data member
    	System.out.println(x);
    }
	public static void main(String[] args) {
		
		DataMemberExample obj= new DataMemberExample();
	    System.out.println(obj.x);
	    obj.fun();
		
	}

}
