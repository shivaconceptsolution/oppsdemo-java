package scs.oopsexample;

public class StaticblockExample {
static int a,b,c;
int a1=2,b1=3;
{
	a1=100;
	b1=200;
}
StaticblockExample()
{
	System.out.println(a1+b1);
	
}


static
{
	a=100;
	b=200;
	c=a+b;
	System.out.println(c);
}

public static void main(String args[])
{
	a=10;
	b=2;
	c=a+b;
	System.out.println(c);
	StaticblockExample obj = new StaticblockExample();
	
}

static
{
	a=100;
	b=200;
	c=a-b;
	System.out.println(c);
}
{
	a1=10;
	b1=20;
}
}
