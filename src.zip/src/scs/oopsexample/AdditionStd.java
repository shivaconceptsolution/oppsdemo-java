package scs.oopsexample;

public class AdditionStd {

	static int a,b,c;
	static void accept(int a, int b)
	{
		AdditionStd.a=a;
		AdditionStd.b=b;
	}
	
	static void add()
	{ 
		AdditionStd.c = AdditionStd.a+AdditionStd.b;
	}
	
	static void display()
	{
		System.out.println(AdditionStd.c);
	}
	
	public static void main(String args[])
	{
		
		AdditionStd.accept(100, 20);
		AdditionStd.add();
		AdditionStd.display();
	}
}
