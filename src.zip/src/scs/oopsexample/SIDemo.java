package scs.oopsexample;

public class SIDemo {
   float p,r,t,si;
   SIDemo(float p,float r,float t)
   {
	   this.p=p;
	   this.r=r;
	   this.t=t;
   }
   void siLogic()
   {
      si = (p*r*t)/100;	   
   }
   void display()
   {
	   System.out.println("result is "+si);
   }
	public static void main(String[] args) {
		
		SIDemo obj = new SIDemo(24000.34F, 2.22F, 2);
		obj.siLogic();
		obj.display();

	}

}
