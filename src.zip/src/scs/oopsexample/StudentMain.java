package scs.oopsexample;
import java.util.Scanner;
public class StudentMain {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int size;
	System.out.println("Enter size of object array");
	size=sc.nextInt();
	Student s[] = new Student[size];
	for(int i=0;i<s.length;i++)
	{
		s[i] = new Student();
		s[i].accept();
	}
	for(int i=0;i<s.length;i++)
	{
		
		s[i].display();;
	}
      /*   Student s = new Student();
         s.accept();
         s.display();
         Student s1 = new Student();
         s1.accept();
         s1.display();*/
		
	}

}
