package scs.oopsexample;

public class Addition {

	public static void main(String[] args) {
		int a=100,b=20,c=0;
		c=a+b;
		System.out.println(c);
		

	}

}
