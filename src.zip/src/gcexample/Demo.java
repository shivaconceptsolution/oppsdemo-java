package gcexample;

public class Demo {
  public void finalize()
  {
	  System.out.println("finilize method");
  }
  public static void main(String args[])
  {
	  Demo obj = new Demo();
	  obj = null;
	  System.gc();
  }
}
