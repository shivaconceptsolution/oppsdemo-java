package thread;

public class Table {
	public  void displayTable(int num ) throws InterruptedException
	{
		
		for(int i=1;i<=10;i++)
		{
			System.out.println("Table is "+num*i);
			
			//Thread.sleep(1000);
		}
		
	}

}
