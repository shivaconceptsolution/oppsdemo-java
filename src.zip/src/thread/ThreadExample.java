package thread;

public class ThreadExample extends Thread
{
    public void run()
     {
    	for(int i=1;i<=5;i++)
    	{
    		System.out.println("Process "+i + Thread.currentThread().getName());
    		Thread.yield();
			
    		
    	}
    	System.out.println("Thred Process end");
     }
    
    public static void main(String arg[]) throws InterruptedException
    {
    	ThreadExample obj = new ThreadExample();
    	obj.start();
    	
    //	obj.join();
    	ThreadExample obj1 = new ThreadExample();
    	obj1.start();
    	
    	//ThreadExample.yield();
    	///obj.join(5000); // it internally use wait()
    //	ThreadExample obj1 = new ThreadExample();
    //	obj1.start();
    	
    }
}
