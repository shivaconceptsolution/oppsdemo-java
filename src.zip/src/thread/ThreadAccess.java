package thread;

public class ThreadAccess {

	public static void main(String[] args) {
		Table t = new Table();
		Thread1 t1 = new Thread1(t);
		t1.start();
		Thread2 t2 = new Thread2(t);
		t2.start();

	}

}
