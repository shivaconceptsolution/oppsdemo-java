package thread;

public class Thread2 extends Thread{
	  Table t;
	  Thread2(Table t)
	  {
		  this.t=t;
	  }
	  public void run()
	  {
		  try {
			t.displayTable(11);
		} catch (InterruptedException e) {
			
		}
	  }
}
