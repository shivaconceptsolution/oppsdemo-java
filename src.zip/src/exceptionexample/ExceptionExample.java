package exceptionexample;
import java.util.InputMismatchException;
import java.util.Scanner;
public class ExceptionExample {
     public static void main(String args[])
     {
    	 Scanner sc = new Scanner(System.in);
	     int a,b,c;
	     String s="success";
    	 try
    	 {
    	
    	 System.out.println("Enter First Number");
    	 a = sc.nextInt();
    	 System.out.println("Enter Second Number");
    	 b = sc.nextInt();
    	 c=0;
    	 try
    	 {
    	 c=a/b;
    	 }
    	 catch(ArithmeticException ex)
    	 {
    		 s = "error";
    		 System.out.println("Denominator can not be zero");
    	 }
    	 System.out.println(c);
    	 }
    	
    	 
    	 catch(InputMismatchException ex)
    	 {
    		 s="error";
    		 int a1=100,b1=0,c1;
    		 try
        	 {
        	 c1=a1/b1;
        	 }
        	 catch(ArithmeticException ex1)
        	 {
        		 s = "error";
        		 System.out.println("Denominator can not be zero");
        	 }
    		 System.out.println("Enter only integer value");
    	 }
    	 finally
    	 {
    		 System.out.println(s);
    	 }
    	 
     }
}
