package exceptionexample;
import java.util.Scanner;
public class ThrowExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
         Scanner sc = new Scanner(System.in);
         String name;
         System.out.println("Enter name");
         name = sc.next();
         if(name.equals("Nitin"))
         {
        	 throw new NameException();
         }
         else
         {
        	 System.out.println("Name is "+name);
         }
		}
		catch(NameException ex)
		{
			 System.out.println(ex.getMessage());
		}
	}

}

class NameException extends RuntimeException
{
	public String getMessage()
	{
		return "Invalid Name";
	}
}
