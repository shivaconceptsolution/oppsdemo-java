package package1;

public class AccessExample2 {

	public static void main(String[] args) {
		AcceessSpecifierExample obj = new AcceessSpecifierExample();
		obj.fun2();
		obj.fun3();
		obj.fun4();
		

	}

}
