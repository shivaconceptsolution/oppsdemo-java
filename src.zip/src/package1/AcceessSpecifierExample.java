package package1;

public class AcceessSpecifierExample {
   private void fun1()
   {
	   System.out.println("Private");
   }
   protected void fun2()
   {
	   System.out.println("Protected");
   }
    void fun3()
   {
	   System.out.println("Default");
   }
    public void fun4()
    {
 	   System.out.println("Public");
    }
}
